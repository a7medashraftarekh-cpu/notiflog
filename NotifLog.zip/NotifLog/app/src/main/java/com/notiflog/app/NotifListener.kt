package com.notiflog.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {

    private var lastKey = ""
    private var lastTime = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            val n = sbn.notification ?: return
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

            val e = n.extras
            val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            if (title.isBlank() && text.isBlank()) return

            val now = System.currentTimeMillis()
            val key = "${sbn.packageName}|$title|$text"
            if (key == lastKey && now - lastTime < 1500) return
            lastKey = key; lastTime = now

            val label = try {
                val ai = packageManager.getApplicationInfo(sbn.packageName, 0)
                packageManager.getApplicationLabel(ai).toString()
            } catch (ex: Exception) { sbn.packageName }

            NotifDb(this).insert(sbn.packageName, label, title, text, sbn.postTime.takeIf { it > 0 } ?: now)
        } catch (_: Exception) {
        }
    }
}
