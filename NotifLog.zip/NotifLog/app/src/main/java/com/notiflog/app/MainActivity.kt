package com.notiflog.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var db: NotifDb
    private lateinit var adapter: NotifAdapter
    private lateinit var banner: View
    private lateinit var spinner: Spinner
    private lateinit var countView: TextView
    private lateinit var empty: TextView

    private var filterPkg: String? = null
    private var query = ""
    private var apps: List<Pair<String, String>> = emptyList()
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 3000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = NotifDb(this)

        banner = findViewById(R.id.banner)
        spinner = findViewById(R.id.spinner)
        countView = findViewById(R.id.count)
        empty = findViewById(R.id.empty)

        adapter = NotifAdapter()
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<Button>(R.id.btnPermission).setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("مسح كل السجل؟")
                .setPositiveButton("مسح") { _, _ -> db.clear(); refresh() }
                .setNegativeButton("إلغاء", null)
                .show()
        }

        findViewById<EditText>(R.id.search).addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val newPkg = if (pos == 0) null else apps.getOrNull(pos - 1)?.first
                if (newPkg != filterPkg) { filterPkg = newPkg; loadList() }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    private fun refresh() {
        val enabled = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        banner.visibility = if (enabled) View.GONE else View.VISIBLE
        loadApps()
        loadList()
    }

    private fun loadApps() {
        val fresh = db.apps()
        if (fresh == apps) return
        apps = fresh
        val names = listOf("كل التطبيقات") + apps.map { it.second }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val idx = apps.indexOfFirst { it.first == filterPkg }
        spinner.setSelection(if (idx >= 0) idx + 1 else 0)
    }

    private fun loadList() {
        val items = db.query(filterPkg, query)
        adapter.submit(items)
        countView.text = "${items.size} / ${db.count()}"
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    class NotifAdapter : RecyclerView.Adapter<NotifAdapter.VH>() {
        private var items: List<NotifEntry> = emptyList()
        private val palette = intArrayOf(
            Color.parseColor("#00E5FF"), Color.parseColor("#69F0AE"),
            Color.parseColor("#FF4081"), Color.parseColor("#B388FF"),
            Color.parseColor("#FFD740"), Color.parseColor("#FF6E40")
        )
        private val fmt = SimpleDateFormat("yyyy/MM/dd  hh:mm:ss a", Locale.getDefault())

        fun submit(list: List<NotifEntry>) {
            if (list.size == items.size && list.firstOrNull()?.id == items.firstOrNull()?.id) return
            items = list; notifyDataSetChanged()
        }

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val bar: View = v.findViewById(R.id.bar)
            val app: TextView = v.findViewById(R.id.app)
            val time: TextView = v.findViewById(R.id.time)
            val title: TextView = v.findViewById(R.id.title)
            val text: TextView = v.findViewById(R.id.text)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_notif, p, false))

        override fun onBindViewHolder(h: VH, i: Int) {
            val e = items[i]
            val c = palette[(e.pkg.hashCode() and 0x7fffffff) % palette.size]
            h.bar.setBackgroundColor(c)
            h.app.setTextColor(c)
            h.app.text = e.app
            h.time.text = fmt.format(Date(e.time))
            h.title.text = e.title
            h.title.visibility = if (e.title.isBlank()) View.GONE else View.VISIBLE
            h.text.text = e.text
            h.text.visibility = if (e.text.isBlank()) View.GONE else View.VISIBLE
        }

        override fun getItemCount() = items.size
    }
}
