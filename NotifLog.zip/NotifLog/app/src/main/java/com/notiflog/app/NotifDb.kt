package com.notiflog.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class NotifEntry(
    val id: Long,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long
)

class NotifDb(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "notifs.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE notifs (id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "pkg TEXT, app TEXT, title TEXT, text TEXT, time INTEGER)"
        )
        db.execSQL("CREATE INDEX idx_time ON notifs(time)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    @Synchronized
    fun insert(pkg: String, app: String, title: String, text: String, time: Long) {
        val v = ContentValues().apply {
            put("pkg", pkg); put("app", app); put("title", title)
            put("text", text); put("time", time)
        }
        writableDatabase.insert("notifs", null, v)
    }

    fun query(pkg: String?, q: String, limit: Int = 1000): List<NotifEntry> {
        val where = StringBuilder("1=1")
        val args = ArrayList<String>()
        if (pkg != null) { where.append(" AND pkg=?"); args.add(pkg) }
        if (q.isNotBlank()) {
            where.append(" AND (title LIKE ? OR text LIKE ? OR app LIKE ?)")
            val l = "%${q.trim()}%"
            args.add(l); args.add(l); args.add(l)
        }
        val out = ArrayList<NotifEntry>()
        readableDatabase.rawQuery(
            "SELECT id,pkg,app,title,text,time FROM notifs WHERE $where ORDER BY time DESC LIMIT $limit",
            args.toTypedArray()
        ).use { c ->
            while (c.moveToNext()) {
                out.add(NotifEntry(c.getLong(0), c.getString(1), c.getString(2),
                    c.getString(3) ?: "", c.getString(4) ?: "", c.getLong(5)))
            }
        }
        return out
    }

    fun apps(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        readableDatabase.rawQuery(
            "SELECT pkg, app FROM notifs GROUP BY pkg ORDER BY app COLLATE NOCASE", null
        ).use { c -> while (c.moveToNext()) out.add(c.getString(0) to c.getString(1)) }
        return out
    }

    fun count(): Int =
        readableDatabase.rawQuery("SELECT COUNT(*) FROM notifs", null).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }

    @Synchronized
    fun clear() { writableDatabase.delete("notifs", null, null) }
}
